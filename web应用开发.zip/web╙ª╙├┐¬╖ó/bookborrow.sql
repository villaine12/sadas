/*
 Navicat Premium Data Transfer

 Source Server         : 我的数据库
 Source Server Type    : MySQL
 Source Server Version : 50721
 Source Host           : localhost:3306
 Source Schema         : bookborrow

 Target Server Type    : MySQL
 Target Server Version : 50721
 File Encoding         : 65001

 Date: 22/06/2019 00:57:18
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book`  (
  `book_id` int(5) NOT NULL AUTO_INCREMENT,
  `book_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sort_id` int(5) NULL DEFAULT NULL,
  `book_author` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `book_pub` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `book_price` float(10, 2) NULL DEFAULT NULL,
  `isbn` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `img` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`book_id`) USING BTREE,
  INDEX `sort_id`(`sort_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES (1, '月亮与六便士', 1, '毛姆', '浙江文艺出版社', 39.80, '9787533936020', NULL);
INSERT INTO `book` VALUES (2, '百年孤独', 1, '加西亚·马尔克斯', '南海出版公司', 53.90, '9787544291170', NULL);
INSERT INTO `book` VALUES (3, '活着', 1, '余华', '作家出版社', 28.00, '9787506365437', NULL);
INSERT INTO `book` VALUES (4, 'Python编程 从入门到实践', 2, '埃里克·马瑟斯', '人民邮电出版社', 89.00, '9787115428028', NULL);
INSERT INTO `book` VALUES (5, '墨菲定律', 2, '张文成', '古吴轩出版社', 20.50, '9787554609491', NULL);
INSERT INTO `book` VALUES (6, '数学之美', 2, '吴军', '人民邮电出版社', 41.10, '9787115373557', NULL);
INSERT INTO `book` VALUES (7, '鬼谷子', 3, '鬼谷子', '吉林美术出版社', 25.20, '9787538693010', NULL);
INSERT INTO `book` VALUES (8, '观山海', 3, '杉泽 ', '湖南文艺出版社', 149.50, '9787540485696', NULL);
INSERT INTO `book` VALUES (9, '明朝那些事儿', 3, '当年明月 ', '北京联合出版有限公司', 240.00, '9787559602152', NULL);

-- ----------------------------
-- Table structure for manager
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager`  (
  `manager_id` int(5) NOT NULL AUTO_INCREMENT,
  `manager_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `manager_password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `manager_age` int(2) NULL DEFAULT NULL,
  `manager_tel` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`manager_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of manager
-- ----------------------------
INSERT INTO `manager` VALUES (1, '123456', '123456', 19, '17689765678');
INSERT INTO `manager` VALUES (2, 'admin', 'admin', 20, '18976785432');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `stu_id` int(5) NOT NULL AUTO_INCREMENT,
  `stu_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `stu_password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `stu_sex` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `stu_age` int(2) NOT NULL,
  `stu_major` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `stu_class` int(4) NOT NULL,
  `stu_star_level` int(1) NOT NULL DEFAULT 3,
  PRIMARY KEY (`stu_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 51 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES (1, '杜立志', '20160001', '男', 18, '软件', 1601, 3);
INSERT INTO `student` VALUES (2, '李佳林', '20160002', '男', 21, '软件', 1601, 3);
INSERT INTO `student` VALUES (3, '王志文', '20160003', '男', 20, '软件', 1601, 3);
INSERT INTO `student` VALUES (4, '李峰帆', '20160004', '女', 19, '软件', 1601, 3);
INSERT INTO `student` VALUES (5, '郭旭', '20160005', '女', 20, '软件', 1601, 3);
INSERT INTO `student` VALUES (6, '李世隆', '20160006', '女', 21, '大数据', 1602, 3);
INSERT INTO `student` VALUES (7, '陈驰', '20160007', '男', 18, '大数据', 1602, 3);
INSERT INTO `student` VALUES (8, '杨博成', '20160008', '男', 19, '大数据', 1602, 3);
INSERT INTO `student` VALUES (9, '杨陈友', '20160009', '男', 19, '大数据', 1602, 3);
INSERT INTO `student` VALUES (10, '李宇航', '20160010', '女', 18, '大数据', 1602, 3);
INSERT INTO `student` VALUES (11, '李福稳', '20160011', '女', 18, '大数据', 1602, 3);
INSERT INTO `student` VALUES (12, '罗最', '20160012', '女', 19, '大数据', 1602, 3);
INSERT INTO `student` VALUES (13, '蒋连杰', '20160013', '男', 18, '网络', 1603, 3);
INSERT INTO `student` VALUES (14, '马骏骁', '20160014', '男', 22, '网络', 1603, 3);
INSERT INTO `student` VALUES (15, '任双庆', '20160015', '女', 18, '网络', 1603, 3);
INSERT INTO `student` VALUES (16, '柯昌涵', '20160016', '女', 21, '数媒', 1604, 3);
INSERT INTO `student` VALUES (17, '张承兴', '20160017', '女', 18, '数媒', 1604, 3);
INSERT INTO `student` VALUES (18, '周小明', '20160018', '男', 19, '数媒', 1604, 3);
INSERT INTO `student` VALUES (19, '汪仕杰', '20160019', '男', 19, '数媒', 1604, 3);
INSERT INTO `student` VALUES (20, '汪硕', '20160020', '女', 19, '软件', 1601, 3);
INSERT INTO `student` VALUES (21, '魏莘原', '20160021', '男', 18, '软件', 1601, 3);
INSERT INTO `student` VALUES (22, '胡宇宏', '20160022', '男', 22, '软件', 1601, 3);
INSERT INTO `student` VALUES (23, '舒文其', '20160023', '女', 18, '软件', 1601, 3);
INSERT INTO `student` VALUES (24, '杨志强', '20160024', '女', 21, '软件', 1601, 3);
INSERT INTO `student` VALUES (25, '陈子博', '20160025', '男', 18, '大数据', 1602, 3);
INSERT INTO `student` VALUES (26, '胡康路', '20160026', '男', 19, '大数据', 1602, 3);
INSERT INTO `student` VALUES (27, '罗梓豪', '20160027', '女', 19, '大数据', 1602, 3);
INSERT INTO `student` VALUES (28, '郭威', '20160028', '男', 19, '大数据', 1602, 3);
INSERT INTO `student` VALUES (29, '祝靖', '20160029', '男', 18, '大数据', 1602, 3);
INSERT INTO `student` VALUES (30, '曹振邦', '20160030', '女', 22, '大数据', 1602, 3);
INSERT INTO `student` VALUES (31, '李前睿', '20160031', '女', 18, '大数据', 1602, 3);
INSERT INTO `student` VALUES (32, '王仁科', '20160032', '男', 21, '网络', 1603, 3);
INSERT INTO `student` VALUES (33, '向文智', '20160033', '女', 18, '网络', 1603, 3);
INSERT INTO `student` VALUES (34, '潘冠华', '20160034', '男', 19, '网络', 1603, 3);
INSERT INTO `student` VALUES (35, '路鹏', '20160035', '男', 19, '数媒', 1604, 3);
INSERT INTO `student` VALUES (36, '谢帅奇', '20160036', '女', 19, '数媒', 1604, 3);
INSERT INTO `student` VALUES (37, '吴智佼', '20160037', '女', 18, '数媒', 1604, 3);
INSERT INTO `student` VALUES (38, '熊子涵', '20160038', '女', 22, '数媒', 1604, 3);
INSERT INTO `student` VALUES (39, '罗文峰', '20160039', '男', 18, '软件', 1601, 3);
INSERT INTO `student` VALUES (40, '李升旗', '20160040', '女', 21, '软件', 1601, 3);
INSERT INTO `student` VALUES (41, '周天翼', '20160041', '男', 18, '软件', 1601, 3);
INSERT INTO `student` VALUES (42, '杨粤', '20160042', '男', 19, '软件', 1601, 3);
INSERT INTO `student` VALUES (43, '曾梦圆', '20160043', '女', 19, '软件', 1601, 3);
INSERT INTO `student` VALUES (44, '付钰铭', '20160044', '女', 19, '大数据', 1602, 3);
INSERT INTO `student` VALUES (45, '谢冠宇', '20160045', '女', 18, '大数据', 1602, 3);
INSERT INTO `student` VALUES (46, '余启东', '20160046', '男', 22, '大数据', 1602, 3);
INSERT INTO `student` VALUES (47, '张祥龙', '20160047', '女', 18, '大数据', 1602, 3);
INSERT INTO `student` VALUES (48, '周航舟', '20160048', '男', 21, '大数据', 1602, 3);
INSERT INTO `student` VALUES (49, '许锐', '20160049', '男', 18, '大数据', 1602, 3);
INSERT INTO `student` VALUES (50, 'student', 'student', '男', 18, '无', 1701, 0);

SET FOREIGN_KEY_CHECKS = 1;
